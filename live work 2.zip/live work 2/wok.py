from flask import Flask, request, jsonify
from flask_cors import CORS
import smtplib
import geocoder
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Initialize Flask app and enable CORS
app = Flask(__name__)
CORS(app)  # Allow cross-origin requests

logging.basicConfig(level=logging.DEBUG)

def get_location():
    """Get the current location (latitude and longitude) based on IP address."""
    g = geocoder.ip('me')
    return g.latlng if g.ok else None

def send_sos_email(to_email, from_email, password):
    """Send an SOS email with the current location."""
    location = get_location()
    if not location:
        logging.error("Failed to get location.")
        return "Failed to get location."

    subject = "SOS Alert!"
    body = f"Help! I'm in danger. My current location is:\nLatitude: {location[0]}\nLongitude: {location[1]}\n"
    
    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(from_email, password)
        server.send_message(msg)
        server.quit()
        logging.info("SOS email sent successfully!")
        return "SOS email sent successfully!"
    except Exception as e:
        logging.error(f"Error sending email: {e}")
        return f"Error sending SOS email: {e}"

@app.route('/send_sos', methods=['POST'])
def send_sos():
    """API endpoint to send SOS email."""
    data = request.json
    from_email = data.get('from_email')
    password = data.get('password')
    to_email = data.get('to_email')

    if not all([from_email, password, to_email]):
        return jsonify({'message': 'All fields are required.'}), 400

    result = send_sos_email(to_email, from_email, password)
    
    if "Error" in result:
        return jsonify({'message': result}), 500
    
    return jsonify({'message': result})

if __name__ == "__main__":
    app.run(debug=True)
